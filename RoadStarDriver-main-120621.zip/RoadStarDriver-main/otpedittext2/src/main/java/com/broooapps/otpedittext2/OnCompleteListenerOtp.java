package com.broooapps.otpedittext2;

/**
 * Created by Swapnil Tiwari on 2019-07-28.
 * swapnil.tiwari@box8.in
 */
public interface OnCompleteListenerOtp {

    void onCompleteOtp(String value);

}
