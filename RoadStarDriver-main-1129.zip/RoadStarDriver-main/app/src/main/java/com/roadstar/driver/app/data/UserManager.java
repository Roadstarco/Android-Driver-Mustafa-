package com.roadstar.driver.app.data;


import com.roadstar.driver.app.data.preferences.PreferenceUtils;
import com.roadstar.driver.app.data.preferences.SharedPreferenceManager;
import com.roadstar.driver.common.utils.Logger;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by bilal on 11/01/2018.
 */

public class UserManager{

    public static void saveUserData(JSONObject data){

        parseStringAndSave(data, "id", PreferenceUtils.USER_ID);
        parseBooleanAndSave(data, "mpConnected", PreferenceUtils.MP_CONNECTED);
        parseStringAndSave(data, "mp_token_id", PreferenceUtils.MP_TOKEN_ID);
        parseStringAndSave(data, "user_name", PreferenceUtils.USER_NAME);
        parseStringAndSave(data, "first_name", PreferenceUtils.FIRST_NAME);
        parseStringAndSave(data, "last_name", PreferenceUtils.LAST_NAME);
        parseStringAndSave(data, "dni", PreferenceUtils.DNI);
        parseStringAndSave(data, "email", PreferenceUtils.EMAIL);
        parseStringAndSave(data, "telefono", PreferenceUtils.PHONE);
        parseIntegerAndSave(data, "user_type", PreferenceUtils.USER_TYPE);
        parseStringAndSave(data, "gender", PreferenceUtils.GENDER);
        parseStringAndSave(data, "birth", PreferenceUtils.DOB);
        parseStringAndSave(data, "direccion", PreferenceUtils.ADDRESS);
        parseStringAndSave(data, "city", PreferenceUtils.CITY);
        parseStringAndSave(data, "country", PreferenceUtils.COUNTRY);
        parseStringAndSave(data, "state", PreferenceUtils.STATE);
        parseStringAndSave(data, "postalCode", PreferenceUtils.POSTAL_CODE);
        parseStringAndSave(data, "picture", PreferenceUtils.PICTURE);
        parseStringAndSave(data, "created", PreferenceUtils.ACC_CREATED_DATE);

//        parseLongAndSave(data, "avgRating", PreferenceUtils.AVG_RATING);
        parseDoubleAndSave(data, PreferenceUtils.RATING, PreferenceUtils.RATING);
        parseStringAndSave(data, PreferenceUtils.MOVER_TYPE, PreferenceUtils.MOVER_TYPE);
        parseBooleanAndSave(data, PreferenceUtils.SIGNUP_COMPLETED, PreferenceUtils.SIGNUP_COMPLETED);
        parseIntegerAndSave(data, PreferenceUtils.STEP_COMPLETED, PreferenceUtils.STEP_COMPLETED);
    }
    public static void saveAccessToken(JSONObject data){
        parseStringAndSave(data, "token", PreferenceUtils.TOKEN);
    }

    private static void parseLongAndSave(JSONObject data, String key, String prefKey){
        try {
            SharedPreferenceManager.getInstance().save(prefKey, data.has(key) && !data.get(key).equals(null)
                    ? data.getLong(key) :0);
        }catch (JSONException e){
            Logger.caughtException(e);
        }
    }

    private static void parseDoubleAndSave(JSONObject data, String key, String prefKey){
        try {
            SharedPreferenceManager.getInstance().save(prefKey, data.has(key)
                    ? (float) data.getDouble(key) : 0);
        }catch (JSONException e){
            Logger.caughtException(e);
        }
    }
    public static float getUserRating(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.RATING, 0f);
    }
    public static String getUserId(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.USER_ID, "");
    }
    public static String getToken(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.TOKEN, "");
    }
    public static String getUserName(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.USER_NAME, "");
    }

    public static String getFirstname(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.FIRST_NAME, "");
    }

    public static String getLastName(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.LAST_NAME, "");
    }
    public static String getCompanyName(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.COMPANY_NAME, "");
    }

    public static String getEmail(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.EMAIL, "");
    }

    public static String getPhone(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.PHONE, "");
    }
   public static String getSSN(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.DNI, "");
    }

    public static int getType(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.USER_TYPE, 0);
    }

    public static String getGender(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.GENDER, "");
    }

    public static String getDob(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.DOB, "");
    }

    public static String getAddress(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.ADDRESS, "");
    }

    public static String getCity(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.CITY, "");
    }
   public static String getCountry(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.COUNTRY, "");
    }

    public static String getState(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.STATE, "");
    }
    public static String getAccCreatedDate( ) {
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.ACC_CREATED_DATE, "");
    }
    public static String getPostalCode(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.POSTAL_CODE, "");
    }
    public static String getMpTokenId(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.MP_TOKEN_ID, "");
    }
    public static String getImage(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.IMAGE, "");
    }
    public static boolean isMpConnected(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.MP_CONNECTED, false);
    }
    public static boolean isSignUpCompleted(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.SIGNUP_COMPLETED, false);
    }

    public static int stepsCompleted(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.STEP_COMPLETED, 1);
    }

    public static int getRating(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.RATING, 5);
    }

    public static String getMoverType(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.MOVER_TYPE, "");
    }

    private static void parseStringAndSave(JSONObject data, String key, String prefKey){
        try {
            SharedPreferenceManager.getInstance().save(prefKey, data.has(key) && !data.get(key).equals(null)
             ? data.getString(key) : "");
        }catch (JSONException e){
            Logger.caughtException(e);
        }
    }

    private static void parseIntegerAndSave(JSONObject data, String key, String prefKey){
        try {
            SharedPreferenceManager.getInstance().save(prefKey, data.has(key) && !data.get(key).equals(null)
                    ? data.getInt(key) : 0);
        }catch (JSONException e){
            Logger.caughtException(e);
        }
    }

    private static void parseBooleanAndSave(JSONObject data, String key, String prefKey){
        try {
            SharedPreferenceManager.getInstance().save(prefKey, (data.has(key) && !data.get(key).equals(null)) && data.getBoolean(key));
        }catch (JSONException e){
            Logger.caughtException(e);
        }
    }

    public static boolean isUserLoggedIn(){
        return !SharedPreferenceManager.getInstance().
                read(PreferenceUtils.COOKIE, "").equalsIgnoreCase("") &&
                SharedPreferenceManager.getInstance().read(PreferenceUtils.IS_LOGGED_IN, false);
    }

    public static int getNotificationCount() {
        return 0;
    }

    public static void setStepCompleted(int i) {
        SharedPreferenceManager.getInstance().save(PreferenceUtils.STEP_COMPLETED, i);
    }

    public static int getStepCompleted() {
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.STEP_COMPLETED, 1);
    }

    public static void setIsSignUpCompleted(boolean b) {
        SharedPreferenceManager.getInstance().save(PreferenceUtils.SIGNUP_COMPLETED, b);
    }

    public static void setIsOnline(boolean status) {
        SharedPreferenceManager.getInstance().save(PreferenceUtils.IS_ONLINE, status);
    }

    public static boolean isOnline() {
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.IS_ONLINE, false);
    }

    public static void setIsTrial(boolean status) {
        SharedPreferenceManager.getInstance().save(PreferenceUtils.IS_FREE_TRIAL, status);
    }
    public static boolean getIsTrial(){
        return SharedPreferenceManager.getInstance().read(PreferenceUtils.IS_FREE_TRIAL, false);
    }
}
